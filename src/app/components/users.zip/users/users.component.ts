import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject, switchMap } from 'rxjs';
import { User } from 'src/app/model/user.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  refresh$ = new BehaviorSubject(true);
  users?: User[];
  dataSource = new MatTableDataSource<User>();
  displayColoumns = ['sl','name', 'email', 'mobile', 'actions'];
  constructor(private userservice:UserService) { }

  ngOnInit(): void {
    this.refresh$
    .pipe(switchMap(() => this.userservice.getUsers()))
    .subscribe((users) => {
      this.users = users;
      this.dataSource = new MatTableDataSource<User>(users);
    });

  }

}
