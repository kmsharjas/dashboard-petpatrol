import { Component } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );


    navList = [
      {name: 'Products', icon: 'receipt', path: 'products'},
      {name: 'Orders', icon: 'receipt', path: 'orders'},
      {name: 'Users', icon: 'receipt', path: 'users'},
      {name: 'Testimonials', icon: 'receipt', path: 'testimonials'},
    ];

  constructor(private breakpointObserver: BreakpointObserver) {}

}
