export interface Blog {
  id?: number;
  title: string;
  createdAt: string;
  image: string;
  para1: string;
  para2: string;
}
