export interface Testimonial {
  id?: number;
  review: string;
  isShown: boolean;
  customerid?: number;
}
