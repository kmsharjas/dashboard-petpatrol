export interface comboProduct {
  id?:number
  name: string;
  desc: string;
  price: number;
  qty:number;
  images: string;
}
