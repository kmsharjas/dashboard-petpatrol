export interface Offer {
  id?: number;
  offer: string;
  startdate: Date | string;
  enddate: Date | string;
  isofferactive: boolean;
  minimumquantity: 1;
}

// export interface Offer {
//   id: number;
//   offer: string;
// }
