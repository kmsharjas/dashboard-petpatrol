export interface Customer {
  id?: number;
  first_name: string;
  last_name: string;
  mobile: string;
  email: string;
  counter: number;
}
