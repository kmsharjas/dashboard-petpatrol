export interface Banner {
  id?: number;
  image: string;
  h4content: string;
  h2contentbold: string;
  h2contentlight: string;
}
