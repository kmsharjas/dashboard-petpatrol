export interface Country {
  id?: number;
  country: string;
}
