export interface Product {
  id?: number;
  name: string;
  desc: string;
  price: number;
  pdt_img: string;
  vedio_url: string;
  unit: number;
  thumbnail_img?: any;
  isofferactive: boolean;  //offer enable or di
  startdate: Date;
  enddate: Date;
  offertype?: number; // 1 for combo 2 for flat
  iscomboactive?: boolean; //if offer typ 1 then true
  isproductactive?:boolean; //visibility
  mincount?: number;  //min count
  offertitle?: string;  //text field
  percentage?: number;  //text field

}
