import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject, Observable, switchMap } from 'rxjs';
import { Product } from 'src/app/model/product.model';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss'],
})
export class ProductsComponent implements OnInit {
  isOpen = false;
  isEditing = false;

  refresh$ = new BehaviorSubject(true);

  products?: Product[];
  dataSource = new MatTableDataSource<Product>();
  displayColoumns = ['name', 'price', 'offer', 'actions'];
  img:any
  productForm: FormGroup;

  constructor(private productService: ProductService, private fb: FormBuilder) {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      desc: ['', Validators.required],
      price: ['', Validators.required],
      // pdt_img: [null, Validators.required],
      pdt_img: [null],
      vedio_url: ['', Validators.required],
      unit: [null, Validators.required],
      // thumbnail_img: [null, Validators.required],
      thumbnail_img: [null],
      isofferactive: [false, Validators.required],
      // startdate: [null, Validators.required],
      startdate: [new Date('2020-12-03'), Validators.required],
      enddate: [new Date('2020-12-03'), Validators.required],
      // enddate: [null, Validators.required],
      offertype: [null, Validators.required],
      iscomboactive: [false, Validators.required],
      isproductactive: [false, Validators.required],
      mincount: [null, Validators.required],
      percentage: [null, Validators.required],
      offertitle: ['', Validators.required],
    });
  }

  get f() {
    return this.productForm.controls;
  }

  ngOnInit(): void {
    this.refresh$
      .pipe(switchMap(() => this.productService.getProducts()))
      .subscribe((products) => {
        this.products = products;
        this.dataSource = new MatTableDataSource<Product>(products);
      });

    this.productForm.valueChanges.subscribe(console.log);
  }


  onSubmit() {
    const product = this.productForm.value;
    this.isEditing ? this.updateProduct(product) : this.createProduct(product);
  }

  onEdit(product: Product) {
    this.isEditing;
    this.productForm.patchValue(product);
    this.isOpen = true;
  }

  onDelete(product: Product) {
    this.productService.deleteProduct(product).subscribe(() => {
      this.refresh$.next(true);
    });
  }

  createProduct(product: Product) {
    console.log(product);
    this.productService.addProduct(product).subscribe(() => {
      this.refresh$.next(true);
      this.resetVariables();
    });
  }

  updateProduct(product: Product) {
    this.productService.updateProduct(product).subscribe(() => {
      this.refresh$.next(true);
      this.resetVariables();
    });
  }

  resetVariables() {
    this.isOpen = false;
    this.isEditing = false;
  }
}
